import React, { useState } from 'react';
import './App.css';
import ProductList from './components/ProductList';

function App() {
  // Initial Product Data
  const initialProducts = [
    { name: "Smartphone", category: "Electronics", price: 699 },
    { name: "Laptop", category: "Electronics", price: 1299 },
    { name: "Jeans", category: "Clothing", price: 49 },
    { name: "T-Shirt", category: "Clothing", price: 19 },
    { name: "Novel Book", category: "Books", price: 15 },
    { name: "Headphones", category: "Electronics", price: 199 },
    { name: "Jacket", category: "Clothing", price: 89 },
    { name: "Cookbook", category: "Books", price: 25 },
    { name: "Tablet", category: "Electronics", price: 399 },
    { name: "Sneakers", category: "Clothing", price: 59 }
  ];

  // State Management
  const [products] = useState(initialProducts);
  const [activeFilter, setActiveFilter] = useState('All');

  // Function to handle filter change
  const handleFilterChange = (category) => {
    setActiveFilter(category);
  };

  // Filtered Products based on activeFilter
  const filteredProducts = activeFilter === 'All'
    ? products
    : products.filter(product => product.category === activeFilter);

  return (
    <div className="App">
      <header>
        <h1>Our Products</h1>
      </header>
      <ProductList
        products={filteredProducts}
        activeFilter={activeFilter}
        onFilterChange={handleFilterChange}
      />
    </div>
  );
}

export default App;
