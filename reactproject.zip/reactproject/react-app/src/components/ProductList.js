import React from 'react';
import './ProductList.css';
import ProductItem from './ProductItem';

const ProductList = ({ products, activeFilter, onFilterChange }) => {
  // Extract unique categories from products
  const categories = ['All', ...new Set(products.map(product => product.category))];

  // However, to include all possible categories even if some have no products in current filter
  // It might be better to define categories outside or use initialProducts.

  // Since the categories are static in Phase 1, let's define them statically
  const allCategories = ['All', 'Electronics', 'Clothing', 'Books'];

  return (
    <section className="filter-section">
      <div className="buttons">
        {allCategories.map(category => (
          <button
            key={category}
            className={`filter-btn ${activeFilter === category ? 'active' : ''}`}
            onClick={() => onFilterChange(category)}
          >
            {category}
          </button>
        ))}
      </div>
      <div className="product-container">
        {products.length > 0 ? (
          products.map((product, index) => (
            <ProductItem key={index} product={product} />
          ))
        ) : (
          <p>No products available in this category.</p>
        )}
      </div>
    </section>
  );
};

export default ProductList;
